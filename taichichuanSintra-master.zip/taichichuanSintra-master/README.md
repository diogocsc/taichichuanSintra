# Tai Chi Chuan Sintra

Hello ! This projects intendes to lodge a static webpage for Tai Chi Chuan in Sintra.
You are welcome to copy the contents for your own project.
If you do, feel free to refer back to this project.
